import json
from rediscluster import RedisCluster


class RedisClusterAngelFund(object):
    def __init__(self):
        self.startup_nodes = [{"host": "angelfund-redis-cluster.pd20mu.clustercfg.usw1.cache.amazonaws.com", "port": "6379"}]
        self.rc = RedisCluster(startup_nodes=self.startup_nodes, decode_responses=True, skip_full_coverage_check=True)

    def redis_data_setter(self, key, value):
        return self.rc.set(key, value)

    def redis_data_getter(self, key):
        return self.rc.get(key)

    def redis_all_keys(self):
        return self.rc.keys()

    def redis_key_delete(self, key):
        return self.rc.delete(key)

    def redis_all_keys_delete(self, keys):
        for i in keys:
            self.rc.delete(i)
        return True



def lambda_handler(event, context):
    input_body = json.loads(event['body'])
    x_auth_key = event['headers']['x-auth-key']
    request_id = event['requestContext']['requestId']
    redis_operation = event['headers']['redis-operations']

    if x_auth_key == "r#?fW5WJ=n5vk?$n":
        if redis_operation == "set":
            key = input_body.get('key', None)
            value = input_body.get('value', None)
            if key is None:
                return_obj = {
                    "result": "key not found in json body"
                }
                return_response = { "body": json.dumps(return_obj) }
                return return_response
            if value is None:
                return_obj = {
                    "result": "value not found in json body"
                }
                return_response = { "body": json.dumps(return_obj) }
                return return_response
            else:
                rc_obj = RedisClusterAngelFund()
                set_obj = rc_obj.redis_data_setter(key, value)
                return_obj = { "result": set_obj }
                return_response = { "body": json.dumps(return_obj) }
                return return_response

        elif redis_operation == "get":
            key = input_body.get('key', None)
            if key is None:
                return_obj = {
                    "result": "key not found in json body"
                }
                return_response = { "body": json.dumps(return_obj) }
                return return_response
            else:
                rc_obj = RedisClusterAngelFund()
                get_obj = rc_obj.redis_data_getter(key)
                return_obj = { key: get_obj }
                return_response = { "body": json.dumps(return_obj) }
                return return_response

        elif redis_operation == "keys":
            rc_obj = RedisClusterAngelFund()
            keys_obj = rc_obj.redis_all_keys()
            return_obj = { "result": keys_obj }
            return_response = { "body": json.dumps(return_obj) }
            return return_response

        elif redis_operation == "delete":
            key = input_body.get('key', None)
            if key is None:
                return_obj = {
                    "result": "key not found in json body"
                }
                return_response = { "body": json.dumps(return_obj) }
                return return_response
            else:
                rc_obj = RedisClusterAngelFund()
                delete_obj = rc_obj.redis_key_delete(key)
                return_obj = { "result": delete_obj }
                return_response = { "body": json.dumps(return_obj) }
                return return_response

        elif redis_operation == "delete_all":
            rc_obj = RedisClusterAngelFund()
            keys_obj = rc_obj.redis_all_keys()
            delete_all_obj = rc_obj.redis_all_keys_delete(keys_obj)
            return_obj = { "result": delete_all_obj }
            return_response = { "body": json.dumps(return_obj) }
            return return_response

    else:
        result_obj = { "result": "Invalid auth key",
                       "requestId": request_id
                        }
        return_response = { "body": json.dumps(result_obj) }
        return return_response