import os
import json
import boto3
import requests
from pymongo import MongoClient


def invoke_email_lambda(payload):
    invoke_lambda = boto3.client('lambda',
                             aws_access_key_id='AKIA37QSMEYZJRR23GB3',
                             aws_secret_access_key='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'
                             )
    response = invoke_lambda.invoke(
        FunctionName='company_images_failed_beta',
        InvocationType="Event",
        LogType="Tail", 
        Payload=json.dumps(payload).encode('utf-8'))
    return response


def failed_results_db_insert(company_name):
    remote_mongo_uri = 'mongodb://angelfund:9%3C%25kg4sa5a97LPzU%5D%24%5Df%24z@18.144.95.137/admin'
    mongo_client = MongoClient(remote_mongo_uri)
    db = mongo_client.images
    collection = db.companies_failed
    collection.insert_one({"company_name": company_name})


def search_in_database(company_name):
    remote_mongo_uri = 'mongodb://angelfund:9%3C%25kg4sa5a97LPzU%5D%24%5Df%24z@18.144.95.137/admin'
    mongo_client = MongoClient(remote_mongo_uri)
    db = mongo_client.images
    collection = db.companies
    return collection.find_one({"company_name": company_name})


def insert_in_mongo(company_url, company_name):
    remote_mongo_uri = 'mongodb://angelfund:9%3C%25kg4sa5a97LPzU%5D%24%5Df%24z@18.144.95.137/admin'
    mongo_client = MongoClient(remote_mongo_uri)
    db = mongo_client.images
    collection = db.companies
    collection.insert_one({"company_name": company_name,
                     "logo_url": company_url
                    })


def file_upload_to_s3(file, object_name):
    object_name = object_name.split('.')[0]
    file_location = f"/tmp/{object_name}.jpg"
    with open(file_location, 'wb') as f:
        f.write(file.content) 

    bucket = 'angelfund-company-images'
    s3_client = boto3.client('s3',
                             aws_access_key_id='AKIA37QSMEYZJRR23GB3',
                             aws_secret_access_key='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'
                             )
    object_name = object_name + ".jpg"
    s3_client.upload_file(file_location, bucket, object_name,
                             ExtraArgs={'ACL': 'public-read'})
    public_url = f'https://{bucket}.s3-us-west-1.amazonaws.com/{object_name}'
    return public_url


def get_company_images(company_name):
    client_id = "810bdfc31d4d73fb97192859a82ee166818cca6e7812"
    url = "https://api.ritekit.com/v1/images/logo?domain={0}&client_id={1}".format(company_name, client_id)
    
    response = requests.request("GET", url)
    if response.status_code == 200:
        s3_bucket_uri = file_upload_to_s3(response, company_name)
        insert_in_mongo(s3_bucket_uri, company_name)
        return_obj = {
            "company_name": company_name,
            "logo_url": s3_bucket_uri,
            "result": True
        }
        return return_obj
    else:
        return json.loads(response.text)


def lambda_handler(event, context):
    input_body = json.loads(event['body'])
    company_name = input_body['company_name']
    x_auth_key = event['headers']['x-auth-key']
    request_id = event['requestContext']['requestId']
    
    if x_auth_key == "fq5#Q2=]Wbkv#,!k":
        response = search_in_database(company_name)
        if response:
            return_obj = { "result": response['logo_url'],
                           "requestId": request_id
             }
            return_response = { "body": json.dumps(return_obj) }
            return return_response
        else:
            resp = get_company_images(company_name)
            if resp["result"]:
                return_obj = { "result": "successful",
                               "logo_url": resp["logo_url"],
                               "company_name": resp["company_name"],
                               "requestId": request_id
                 }
                return_response = { "body": json.dumps(return_obj) }
                return return_response
            else:
                failed_results_db_insert(company_name)
                return_obj = { "result": "unsuccessful",
                               "message": resp["message"],
                               "requestId": request_id
                                }
                return_response = { "body": json.dumps(return_obj) }
                event['headers']['x-auth-key'] = '-sZF$u*:u5Mc,t7<'
                resp = invoke_email_lambda(event)
                return return_response
    else:
        result_obj = { "result": "Invalid auth key",
                       "requestId": request_id
                        }
        return_response = { "body": json.dumps(result_obj) }
        return return_response